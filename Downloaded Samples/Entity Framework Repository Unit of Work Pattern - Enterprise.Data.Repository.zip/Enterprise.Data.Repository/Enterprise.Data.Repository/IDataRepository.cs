﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using System.Collections.Specialized;

namespace Enterprise.Data.Repository
{
    public interface IDataRepository 
    {
        /// <summary>
        /// Updates entity object
        /// </summary>
        /// <param name="entity"></param>
        void Update<TEntity>(TEntity entity) where TEntity: class;  

        /// <summary>
        /// Provides explicit loading of object properties
        /// </summary>
        void LoadProperty<TEntity>(TEntity entity, Expression<Func<TEntity, object>> selector);

        /// <summary>
        /// Returns all entities for a given type
        /// </summary>
        /// <returns>All entities</returns>
        List<TEntity> GetAll<TEntity>(params string[] NavigationChildren) where TEntity : class;

        /// <summary>
        /// Returns  entities for a given type based on the query string
        /// </summary>
        /// <param name="Query"></param>
        /// <param name="Paramaters"></param>
        /// <returns></returns>
        
         List<TEntity> Search<TEntity>(string Query, params string[] NavigationChildren) where TEntity : class;       

        /// <summary>
        /// Add entity to the repository
        /// </summary>
        /// <param name="entity">the entity to add</param>
        /// <returns>The added entity</returns>
        void Add<TEntity>(TEntity entity) where TEntity : class;


        /// <summary>
        /// Save entity to the repository
        /// </summary>
        /// <param name="entity">the entity to Save</param>
        /// <returns>Saved entity</returns>
        void Save<TEntity>(TEntity entity, int KeyValue) where TEntity : class;


       
        /// <summary>
        /// Mark entity to be deleted within the repository
        /// </summary>
        /// <param name="entity">The entity to delete</param>
        void Delete<TEntity>(TEntity entity) where TEntity : class;

      /// <summary>
        /// Mark entity to be deleted within the repository
        /// </summary>
        /// <param name="entity">The entity to delete</param>
       /// <param name="criteria"> Predicate for entity to be deleted</param>

        void Delete<TEntity>(Expression<Func<TEntity, bool>> criteria) where TEntity : class;

       /// <summary>
       /// 
       /// </summary>
       /// <typeparam name="TEntity"></typeparam>
       /// <param name="criteria"></param>
       /// <param name="NavigationChildren"></param>
       /// <returns></returns>
        List<TEntity> Search<TEntity>(Expression<Func<TEntity, bool>> criteria, params string[] NavigationChildren) where TEntity : class;

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="criteria"></param>
        /// <param name="NavigationChildren"></param>
        /// <returns></returns>
        TEntity First<TEntity>(Expression<Func<TEntity, bool>> criteria, params string[] NavigationChildren) where TEntity : class;
      

    }
}
