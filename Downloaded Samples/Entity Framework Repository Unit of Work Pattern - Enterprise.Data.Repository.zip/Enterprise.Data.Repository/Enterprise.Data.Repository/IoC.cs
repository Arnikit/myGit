﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace Enterprise.Data.Repository
{
    /// <summary>
    /// Locates and resolve dependent instances at runtime.
    /// </summary>
    /// 
    // [Serializable]
    public static class IoC
    {
        #region Fields

        private static readonly IUnityContainer _container = new UnityContainer();

        #endregion Fields

        /// <summary>
        /// Initializes the <see cref="IoC"/> class.
        /// </summary>
        static IoC()
        {
            //// Default mappings
            ////clients can override this by registering types

            try
            {

                InitializeContainer();
            }
            catch
            {
                throw;
            }


        }

        private static void InitializeContainer()
        {

            UnityConfigurationSection section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
            section.Configure(_container,"DataContainer");
          
           
        }

        #region Properties

        /// <summary>
        /// Gets the container.
        /// </summary>
        /// <value>The container.</value>
        public static IUnityContainer Container
        {
            get { return _container; }
        }

        #endregion Properties

        #region Static Methods

        /// <summary>
        /// Registers the type.
        /// </summary>
        /// <typeparam name="TFrom">The type of from.</typeparam>
        /// <typeparam name="TTo">The type of to.</typeparam>
        /// <param name="injectionMembers">The injection members.</param>
        public static void RegisterType<TFrom, TTo>(params InjectionMember[] injectionMembers) where TTo : TFrom
        {
            // register the type
            _container.RegisterType(typeof(TFrom), typeof(TTo), null, null, injectionMembers);
        }

        /// <summary>
        /// Registers the instance.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instance">The instance.</param>
        public static void RegisterInstance<T>(T instance)
        {
            // register the instance
            _container.RegisterInstance(instance);
        }

        /// <summary>
        /// Resolves this instance.
        /// </summary>
        /// <typeparam name="T">The type to resolve.</typeparam>
        /// <returns>The registered instance of type <typeparamref name="T"/>.</returns>
        public static T Resolve<T>()
        {
            // resolve the instance
            return _container.Resolve<T>();
        }

        /// <summary>
        /// Returns an injected implementation for the requested interface
        /// </summary>
        public static object Resolve(Type t)
        {

            return _container.Resolve(t);
        }
        #endregion Static Methods
    }
}

