﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Objects;

namespace Enterprise.Data.Repository
{

    public interface IUnitOfWork
    {
        /// <summary>
        ///  current object context 
        /// </summary>
         ObjectContext objectContext { get; }

        /// <summary>
        /// Save all changes made within the unit of work
        /// </summary>
        /// <returns>Integer with number of objects affected</returns>
        int SaveChanges();

        /// <summary>
        /// Resolves data contract types
        /// </summary>
        /// <param name="DataContractType"></param>
        /// <returns></returns>
        Type GetObjectType(Type DataContractType);

        /// <summary>
        /// Terminates current context
        /// </summary>
        void Terminate();


    }
}
