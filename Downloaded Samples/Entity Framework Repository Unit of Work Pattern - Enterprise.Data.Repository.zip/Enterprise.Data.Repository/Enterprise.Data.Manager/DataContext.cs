﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Objects;
using Enterprise.Data.Repository;

namespace Enterprise.Data.Manager
{

    /// <summary>
    /// Context across all repositories
    /// </summary>
    public class DataContext : IUnitOfWork
    {
     



        /// <summary>
        /// Returns the active object context
        /// </summary>
        public ObjectContext objectContext
        {
            get
            {
                return ContextManager.GetObjectContext();
            }
        }

        #region IUnitOfWork Members

        /// <summary>
        /// Save all changes to all repositories
        /// </summary>
        /// <returns>Integer with number of objects affected</returns>
        
        public int SaveChanges()
        {
            return objectContext.SaveChanges();
        }

        /// <summary>
        /// Returns Data contract type
        /// </summary>
        /// <param name="DataContractType"></param>
        /// <returns></returns>        
        public Type GetObjectType(Type DataContractType)
        {

            return ObjectContext.GetObjectType(DataContractType);
        }

        /// <summary>
        /// Terminates the current repository context
        /// </summary>
        public void Terminate()
        {
            ContextManager.SetRepositoryContext(null);
        }



        #endregion




     
    }

}
