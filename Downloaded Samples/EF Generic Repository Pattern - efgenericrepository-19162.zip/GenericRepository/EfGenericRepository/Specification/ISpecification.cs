﻿namespace EfGenericRepository.Specification
{
    public interface ISpecification<TEntity>
    {
    }
}
